"""
Code to analyse the astronomical image from the Kitts peak 4m telescope. 
It creates a galaxy catalogue containing their positions, size, magnitudes,
local backgorund and the errors associated with these values. 

Written by Verity Cook and Rebecca Dunkley
12/02/2019
"""

import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import numpy as np

from astropy.table import Table
from astropy.io import fits, ascii

import time
start_time = time.time()

#%% Obtain image data
hdulist = fits.open("A1_mosaic.fits")
data0 = hdulist[0].data

hdulist.close()
#%% Functions for manual masking of areas that should not be included in analysis

# Masks ellipse for a given location and size, useful for stars and galaxies
# Inputs:
#    info = list contatining centre, major and minor axis of ellipse
#    data = data to be masked 
#    mask = mask to be altered
#    clr = value between 0 and 1 indicating colour of object on mask
# Outputs:
#    data and mask 
def mask_ellipse(info, data, mask, clr = 1): 
    x0, y0, a, b = info 
    for x in range((x0 - int(a)),(x0 + int(a))):
        for y in range((y0 - int(b)),(y0 + int(b))):
            ell = ((x - x0)/float(a))**2 + ((y - y0)/float(b))**2 
            if ell <= 1.:
                mask[y][x] = clr
                data[y][x] = 0
    return data, mask


# Mask rectangles for a given height, width and loction, useful to mask out 
# blooming from bright stars
# Inputs:
#    info = y co-ords of top and bottom edges, x co-ords of left and right edges 
#    data = data to be masked 
#    mask = mask to be altered
#    clr = value between 0 and 1 indicating colour of object on mask
# Outputs:
#     data and mask
def mask_rect(info, data, mask, clr = 1):
    t, b, l, r = info
    mask[b:t,l:r] = clr
    data[b:t,l:r] = 0
    return data, mask


# Masks trianges for a given base and height, centred at x = 1438, useful for 
# bleeding at the bottom centre of the image
# Inputs:
#    info = list containing x and y co-ords of the base and the y co-ord of the 
#           height
#    data = data to be masked 
#    mask = mask to be altered
#    clr = value between 0 and 1 indicating colour of object on mask
# Outputs:
#     data and mask 
def mask_triangle(info, data, mask, clr = 1):
    x_b, y_b, y_h = info
    x_h = 1438
    
    if x_h - x_b > 0:
        for x in range(x_b, x_h):
            for y in range(y_b, y_h):
                line = ((y_h - y_b) * x + x_h * y_b - x_b * y_h)/(x_h - x_b)
                if y < line:
                    mask[y][x] = clr
                    data[y][x] = 0
    else:
        for x in range(x_h, x_b):
            for y in range(y_b, y_h):
                line = ((y_h - y_b) * x + x_h * y_b - x_b * y_h)/(x_h - x_b)
                if y < line:
                    mask[y][x] = clr
                    data[y][x] = 0
    return data, mask   

#%% Impliment functions to create initial mask
mask_i = np.zeros((4611,2570)) # mask has the same dimensions as data
mask_r = mask_i.copy() # to be used later
data_i = data0.copy()  # don't change original data 


# Remove border where sub-exposures do not overlap
data_i[:127,]   = 0    # bottom
mask_i[:127,]   = 1    

data_i[:,:114]  = 0    # left
mask_i[:,:114]  = 1  

data_i[4513:,]  = 0    # top
mask_i[4513:,]  = 1   

data_i[:,2476:] = 0    # right
mask_i[:,2476:] = 1  


# Remove bright stars from analysis              
                 #[    x,   y,   a,   b]
stars = np.array([[1427, 3208, 280, 280],  # bright star
                  [ 775, 3320,  65,  65],  # star 1
                  [ 975, 2773,  54,  54],  # star 2
                  [ 906, 2287,  52,  52],  # star 3
                  [2136, 3760,  41,  41],  # star 4
                  [2467, 3415,  33,  33],  # star 5
                  [2091, 1426,  32,  32],  # star 6
                  [2131, 2309,  31,  31],  # star 7
                  [558,  4098,  27,  24],  # star 8 (added after run of code revealed it's magnitude was too high to be a galaxy)
                  [1456, 4033,  23,  23],  # star 9 
                  [1414, 3499,  15,  14]]) # star 10
    

for star in stars:
    mask_ellipse(star, data_i, mask_i, 1)

# Remove blooming of brighest stars from analysis
                   #[   t,    b,    l,    r]
blooms =  np.array([[None, None, 1423, 1450],  # bright star
                    [3420, 3202,  771,  781],  # star 1
                    [2837, 2703,  968,  979],  # star 2
                    [2358, 2222,  900,  909],  # star 3
                    [3805, 3706, 2130, 2138]]) # star 4

for bloom in blooms:
    mask_rect(bloom, data_i, mask_i, 1)


# Remove bleeding at the bottom of the image 
                    # [ x_b, y_b, y_h]
triangles = np.array([[1102, 425, 495],
                      [1654, 425, 495],
                      [1017, 313, 367],
                      [1706, 313, 395],
                      [1372, 217, 274],
                      [1488, 215, 292],
                      [1260, 116, 185],
                      [1562, 116 ,186]])

for triangle in triangles:
    mask_triangle(triangle, data_i, mask_i, 1)

#%% Get paramaters for histogram of count values

data_back = [] # list containing values around the background count
data_hist = [] # list containing values to be included in the histogram
for count in data_i.flatten():
    if 3350 < count < 3480:     # range of values for histogram
        data_hist.append(count)
        if 3380 < count < 3450: # range of values for Gaussian parameters
            data_back.append(count)

mu, sigma = np.mean(data_back), np.std(data_back) # mean and std of background
count_range = np.arange(3350, 3480)
gauss = mlab.normpdf(count_range, mu, sigma) # Gaussian fit of background

#%% Produce Histogram
# Prepare plot
fig_hist, ax_hist = plt.subplots()
ax_hist.set_title('Normalised histogram showing distribution of background data')
ax_hist.set_xlabel('Counts') 
ax_hist.set_ylabel('Number of pixels')

# Add histogram and Gaussian fit
ax_hist.hist(data_hist, bins = 64, normed = True)
ax_hist.plot(count_range, gauss, 'r--')

ax_hist.legend(('Gaussian fit', 'Histogram'))
ax_hist.text(3360, 0.03, 
         r'$\mu$ = {:.2f}, $\sigma$ = {:.2f}'.format(mu, sigma), fontsize = 9)

#%% Functions for detecting and masking galaxies 

# Set threshold for source detection 
threshold = mu + 5 * sigma 

# Find location of pixel(s) with the highest count value
# Inputs:
#     data = data containing all the count values
# Outputs:
#     loction of pixel(s) and the count values   
def find_highest(data):
    h = max(data.flatten()) # find highest count value
    loc = np.where(data == h)
    
    # incase there are multiple pixels with the highest value
    x = []
    y = []
    for n in range(len(loc[0])):
        y.append(loc[0][n])
        x.append(loc[1][n])    
    
    y0 = y[0]
    x0 = x[0]
    return x0, y0, h

# Determine the size of the galaxy by searching in the x and y directions 
# until the threshold count value is reached 
# Inputs:
#     loc = array containg x and y co-ord of centre of galaxy (brightest point)
#     data = data containing image information
# Outputs:
#     a and b, the extent of the galaxy in the x and y directions 
def galaxy_size(loc, data):
    global threshold
    x0, y0 = loc
    
    # determine size of each galaxy using major and minor axis
    # search to the right
    a_r = 1       
    while data[y0][x0 + a_r] > threshold:
        a_r += 1
    # search to the left
    a_l = 1
    while data[y0][x0 - a_l] > threshold:
        a_l += 1
    
    # pick largest of two 
    if a_r > a_l:
        a = a_r
    else:
        a = a_l
    
    # search up
    b_u = 1       
    while data[y0 + b_u][x0] > threshold:
        b_u += 1
    
    # search down 
    b_d = 1
    while data[y0 - b_d][x0] > threshold:
        b_d += 1
    
    # pick largest of two 
    if b_u > b_d:
        b = b_u
    else:
        b = b_d
    
    return a, b


# Assuming galaxies are circular
def circ_galaxy(info, data, mask):
    x0, y0, a, b = info
    if a > b:
        r = a
    else:
        r = b
    info1 = [x0, y0, r, r]
    mask_ellipse(info1, data, mask)
    return data, mask

# Assuming galaxies are ellipical, but aligned horizontally or vertically
def ell_galaxy(info, data, mask):
    x0, y0, a, b = info
    mask_ellipse(info, data, mask)
    return data, mask

N = 0 # number of galaxies detected  
galaxy_data = []
def detect_galaxies(data, mask):
    global N, galaxy_data, threshold
    x0, y0, h = find_highest(data)
    a, b = galaxy_size([x0, y0], data)
    info = [x0, y0, a, b]
    
    while h > threshold:
        ell_galaxy(info, data, mask)
        
        # find parameters for next galaxy
        x0, y0, h = find_highest(data)
        a, b = galaxy_size([x0, y0], data)
        info = [x0, y0, a, b]
        if a > 2 and b > 2: 
            N += 1
            galaxy_data.append(info)
        print(N, int(h - threshold))
    return data, mask, N, galaxy_data

# Create mask and data for galaxy detection
mask_g = mask_i.copy() # keep copy of inital mask 
data_g = data_i.copy() # keep copy of inital data after masking
detect_galaxies(data_g, mask_g)
    
#%% Photometry 

# fixed aperture photometry
def source_count_fix(info, data0, r = 6):
    x0, y0, a, b = info
    count = 0
    n = 0
    if a > r or b > r:
        a, b = r, r
    for x in range(x0 - a, x0 + a):
        for y in range(y0 - b, y0 + b):
            ell = ((x - x0)/float(a))**2 + ((y - y0)/float(b))**2
            if ell <= 1:
                value = data0[y][x]
                count += value
                n += 1
    return count, a, b, n

# variable aperture photometry
def source_count_vary(info, data0):
    x0, y0, a, b = info
    count = 0
    n = 0
    for x in range(x0 - a, x0 + a):
        for y in range(y0 - b, y0 + b):
            ell = ((x - x0)/float(a))**2 + ((y - y0)/float(b))**2
            if ell <= 1:
                value = data0[y][x]
                count += value
                n += 1
    return count, a, b, n
    
# Calculate average value of background around a given galaxy
def local_back(info, data, r = 10):
    count = 0
    n = 0 # number of contributing pixels
    x0, y0, a, b = info
    
    for x in range((x0 - (a + r)), x0 + (a + r)):
        for y in range(y0 - (b + r), y0 + (b + r)):
            ell_in  = ((x - x0)/float(a))**2 + ((y - y0)/float(b))**2 # edge of galaxy
            ell_out = ((x - x0)/float(a + r))**2 + ((y - y0)/float(b + r))**2 
            if ell_in > 1 and ell_out < 1: # x, y lies withing ring around galaxy
                value = data[y][x]
                if value != 0 and value < threshold: # value = 0 corresponds to previously detected galaxy
                    count += value
                    n += 1
    back_mean = count/n
    return back_mean 
    
# Calculate the important information of a given galaxy
# Inputs:
#     info = centre position and size of galaxy, array [x0, y0, a, b]
#     data = data after masking of galaxies
#     data0 = initial data, before any masking 
# Outputs:
#     magnitude and error, flux count and error, source count, background count 
def mag(info, data, data0):  
    # find source count
    count, a0, b0, n = source_count_vary(info, data0)
    
    # find background contribution
    back_mean = local_back(info, data)
    back_count = back_mean * n
    
    # calculate net flux count
    flux_count = count - back_count
    count_err = np.sqrt(flux_count) # error in value of flux count 
    
    ZP = 25.30 # zero point
    ZP_err = 2E-2 # error in zero point 
    
    # calculate calibrated magnitude
    m = ZP - 2.5 * np.log10(flux_count)
    # calculate error in magnitude using propagation of errors
    m_err = np.sqrt(ZP_err**2 + (((2.5/np.log(10))/flux_count) * count_err)**2)
    
    return m, m_err, flux_count, count_err, back_count, count

#%% Catalogue galaxy data
x_pos            = []
y_pos            = []
a                = []
b                = []
magnitude        = []
magnitude_err    = []
net_flux_count   = []
flux_count_err   = []
total_background = [] 
total_source     = []

for info in galaxy_data:
    x0, y0, a0, b0 = info
    m, m_err, flux_count, count_err, back_count, count = mag(info, data_g, data_i)
    x_pos.append(x0)
    y_pos.append(y0)
    a.append(a0)
    b.append(b0)
    magnitude.append(m)
    magnitude_err.append(m_err)
    net_flux_count.append(flux_count)
    flux_count_err.append(count_err)
    total_background.append(back_count) 
    total_source.append(count)

galaxy_data_all = Table([x_pos, 
                         y_pos, 
                         a,
                         b,
                         magnitude, 
                         magnitude_err, 
                         net_flux_count, 
                         flux_count_err, 
                         total_background,
                         total_source], 
                 names = ['x position', 
                          'y position', 
                          'radius in x axis',
                          'radius in y axis',
                          'apparent magnitude', 
                          'apparent magnitude error', 
                          'object flux', 
                          'object flux error', 
                          'background count', 
                          'source count'])


#%% Compare data and masks

import math
fig_data, (ax_data, ax_mask, ax_mask_g) = plt.subplots(1, 3)
fig_data.tight_layout()

rainbow = plt.cm.rainbow
ax_data.pcolormesh(data0, cmap = 'Greys')
ax_data.set(xlabel="x",ylabel="y")
ax_data.set_title("Original Data Set", fontsize = 10)
ax_mask.pcolormesh(mask_i, cmap = 'Greys')
ax_mask.set(xlabel="x",ylabel="y")
ax_mask.set_title("Initial Masking", fontsize = 10)

data_r = data_i.copy()

m_wo_nan = [] # list of magnitudes without nan values
normm = [] # list of normalised magnitudes

for m in range(len(magnitude), 0, -1): #eliminates nan values from list of magnitudes
    if math.isnan(magnitude[m-1]) == True:
        #print(galaxy_data_all[m-1])
        galaxy_data_all.remove_row(m-1)
    else:
        m_wo_nan.append(magnitude[m-1])

for g in galaxy_data_all: #normalises magnitudes
    #print(g[4])
    x = (g[4] - min(m_wo_nan) + 0.0001)
    y = (max(m_wo_nan) - min(m_wo_nan))
    #print(x)
    #print(y)
    normm.append(x/y)

for i, g in enumerate(galaxy_data_all): # masks galaxies
    info = g[0], g[1], g[2], g[3]
    mask_ellipse(info, data_r, mask_r, clr = normm[i])

im1 = ax_mask_g.pcolormesh(mask_r, cmap=rainbow, vmin = 0.00001)
im1.cmap.set_under('w')
ax_mask_g.set_xlabel('x')
ax_mask_g.set_ylabel('y')
ax_mask_g.set_title("Masking of Detected Galaxies Only", fontsize = 10)
cbar = plt.colorbar(im1, extend ='min')
cbar.set_label('Relative magnitude of galaxies (1 = dimmest, 0 = brightest)', rotation=270, labelpad = 10)

#%% save data
ascii.write(galaxy_data_all, 
            'galaxy_data_all_vary.csv', 
            format = 'csv', 
            fast_writer = False,
            overwrite = True)     

print("--- %s seconds ---" % (time.time() - start_time))
        

        







    

    

    

    

    

    

    

    

    

    

    

    

    

    

    

    









