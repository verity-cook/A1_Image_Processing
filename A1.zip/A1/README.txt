To analyse the image just run the code. A histogram, the initial mask and the mask 
after the galaxy detection will be returned as well as a csv file that 
contains the information about the galaxies. 